package org.library;

import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import org.library.utils.JDBCUtils;
import org.library.view.*;

public class Main {
    public static void main(String[] args) throws NoSuchAlgorithmException {
        // 测试驱动加载、数据库连接
        Connection connection= JDBCUtils.getConnection();



        Login login=new Login();




    }
}