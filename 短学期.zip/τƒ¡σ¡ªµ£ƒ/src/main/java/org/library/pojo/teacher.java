package org.library.pojo;

import java.util.Optional;

public class teacher {
    // 学号/工号
    private String id;
    // 姓名
    private String name;
    //性别
    private String sex;
    //年龄
    private String age;
    //院系
    private String dept;
    // 密码
    private String password;

    public void set_all(String name, String sex, String age, String dept, String id, String password){
        this.id=id;
        this.sex=sex;
        this.name=name;
        this.age=age;
        this.dept=dept;
        this.password=password;
    }


    public String get_id() {
        return id;
    }

    public void set_id(String id) {
        this.id = id;
    }

    public  String get_sex(){return sex;}
    public void set_sex(String sex){this.sex=sex;}

    public String get_name() {
        return name;
    }

    public void set_name(String name) {
        this.name = name;
    }

    public String get_password() {
        return password;
    }

    public void set_password(String password) {
        this.password = password;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }




    @Override
    //如 System.out.println(user)，这将自动调用 toString() 方法，
    public String toString() {

        String adminInfo=String.format("Admin:{id=%s,sex=%s,name=%s,age=%s,dept=%s,password=%s}",
                Optional.ofNullable(id).orElse(""),
                Optional.ofNullable(sex).orElse(""),
                Optional.ofNullable(name).orElse(""),
                Optional.ofNullable(age).orElse(""),
                Optional.ofNullable(dept).orElse(""),
                Optional.ofNullable(password).orElse(""));
        return adminInfo;
    }


}
