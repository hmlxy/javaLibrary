package org.library.pojo;
//plain ordinary java object，简单java对象；⼀般专指只有 set_ter/get_ter/toString 的简单类；pojo⽤于数据
//的临时传递，它只能装载数据， 作为数据存储的载体，⽽不具有业务逻辑处理的能⼒。pojo层命名为entity也可，
//表示实体层

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/** 学生类 */
public class book {
    // 图书编号
    private String id;
    // 图书名称
    private String name;
    // 作者
    private String author;
    // 类别
    private String category;
    // 位置
    private String place;
    // 出版社
    private String publisher;
    // 出版日期
    private LocalDate year;
    // 借阅状态
    private String status;
    // 读者id
    private String uid;
    // 借书日期
    private LocalDate brodate;
    // 应还日期
    private LocalDate returndate;

    public void set_all(String id,String name,String author,String category,String place,String publisher,
                        String year,String status,String uid,int borrow_time){

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        this.id=id;
        this.name=name;
        this.author=author;
        this.category=category;
        this.place=place;
        this.publisher=publisher;
        if(year!=null &&!year.isEmpty()){
            this.year=LocalDate.parse(year,formatter);
        }
        else{
            this.year=null;
        }

        this.status=status;
        this.uid=uid;
        if(this.uid!=null ){
            this.brodate=LocalDate.now();
            this.returndate=this.brodate.plusDays(borrow_time);

        }
    }

    public void set_all(String id,String name,String author,String category,String place,String publisher,
                        String year,String status){

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        this.id=id;
        this.name=name;
        this.author=author;
        this.category=category;
        this.place=place;
        this.publisher=publisher;
        if(year!=null &&!year.isEmpty()){
            this.year=LocalDate.parse(year,formatter);
        }
        else{
            this.year=null;
        }

        this.status=status;
    }
    public void set_all(String id,String name,String author,String category,String place,String publisher,
                        String year,String status,String uid,String brodate,String returndate){

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        this.id=id;
        this.name=name;
        this.author=author;
        this.category=category;
        this.place=place;
        this.publisher=publisher;
        this.year=LocalDate.parse(year,formatter);
        this.status=status;
        this.uid=uid;
        this.brodate=LocalDate.parse(brodate,formatter);
        this.returndate=LocalDate.parse(returndate,formatter);
    }
    public String get_id() {
        return id;
    }

    public void set_id(String id) {
        this.id = book.this.id;
    }
    public String get_name() {
        return name;
    }

    public void set_name(String name) {
        this.name = book.this.name;
    }
    public String get_author() {
        return author;
    }

    public void set_author(String author) {
        this.author = author;
    }
    public String get_category() {
        return category;
    }

    public void set_category(String category) {
        this.category = category;
    }


    public String get_place() {
        return place;
    }

    public void set_place(String place) {
        this.place = place;
    }

    public String get_publisher() {
        return publisher;
    }

    public void set_publisher(String publisher) {
        this.publisher = publisher;
    }

    public LocalDate get_year() {
        return year;
    }

    public void set_year(LocalDate year) {
        this.year = year;
    }

    public String get_status() {
        return status;
    }

    public void set_status(String status) {
        this.status = status;
    }

    public String get_uid() {
        return uid;
    }

    public void set_uid(String uid) {
        this.uid = uid;
    }

    public LocalDate get_brodate() {
        return brodate;
    }

    public void set_brodate(LocalDate brodate) {
        this.brodate = brodate;
    }
    public LocalDate get_returndate() {
        return returndate;
    }

    public void set_returndate(LocalDate returndate) {
        this.returndate = returndate;
    }




    @Override
    //如 System.out.println(user)，这将自动调用 toString() 方法，
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        //要注意到空值导致的转化为String错误NullPointerException
        String bookInfo = String.format("Book:{id=%s,name=%s,author=%s,category=%s,place=%s,publisher=%s,year=%s,status=%s,uid=%s,brodate=%s,returndate=%s}",
                Optional.ofNullable(id).orElse(""),
                Optional.ofNullable(name).orElse(""),
                Optional.ofNullable(author).orElse(""),
                Optional.ofNullable(category).orElse(""),
                Optional.ofNullable(place).orElse(""),
                Optional.ofNullable(publisher).orElse(""),
                //要注意到空值导致的转化为String错误NullPointerException
                Optional.ofNullable(year).map(formatter::format).orElse(""),
                Optional.ofNullable(status).orElse(""),
                Optional.ofNullable(uid).orElse(""),
                //要注意到空值导致的转化为String错误NullPointerException
                Optional.ofNullable(brodate).map(formatter::format).orElse(""),
                Optional.ofNullable(returndate).map(formatter::format).orElse(""));
        return bookInfo;
    }
}
