package org.library.pojo;

import java.util.Optional;

public class library_manager {
    // 学号/工号
    private String id;
    // 姓名
    private String name;
    // 密码
    private String password;
    // 电话
    private String phone;

    private String sex;

    public void set_all(String id,String sex,String name,String password,String phone){
        this.id=id;
        this.sex=sex;
        this.name=name;
        this.password=password;
        this.phone=phone;
    }
    public String get_id() {
        return id;
    }

    public void set_id(String id) {
        this.id = id;
    }

    public  String get_sex(){return sex;}
    public void set_sex(String sex){this.sex=sex;}
    public String get_name() {
        return name;
    }

    public void set_name(String name) {
        this.name = name;
    }

    public String get_password() {
        return password;
    }

    public void set_password(String password) {
        this.password =password;
    }

    public String get_phone() {
        return phone;
    }

    public void set_phone(String phone) {
        this.phone = phone;
    }




    @Override
    //如 System.out.println(user)，这将自动调用 toString() 方法，
    public String toString() {

        String adminInfo=String.format("Admin:{id=%s,sex=%s,name=%s,password=%s,phone=%s}",
                Optional.ofNullable(id).orElse(""),
                Optional.ofNullable(sex).orElse(""),
                Optional.ofNullable(name).orElse(""),
                Optional.ofNullable(password).orElse(""),
                Optional.ofNullable(phone).orElse(""));
        return adminInfo;
    }
}
