package org.library.view;

import org.library.service.*;
import org.library.pojo.teacher;
import org.library.service.impl.teacher_serviceImpl;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Library_teacher_manage extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    public static String id="";
    public static String name="";
    public static String sex="";
    public static String age="";
    public static String college="";
    public static String password="";

    public Library_teacher_manage() {
        setTitle("图书管理系统");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);//绝对布局

        JLabel label = new JLabel("教师读者管理");
        label.setFont(new Font("宋体", Font.BOLD, 30));
        label.setBounds(50, 30, 300, 80);
        add(label);

        JTextField searchField = new JTextField();
        searchField.setBounds(400, 50, 200, 50);
        add(searchField);

        JButton searchButton = new JButton("查询");
        searchButton.setBounds(620, 50, 100, 50);
        add(searchButton);

        JButton backButton = new JButton("返回");
        backButton.setBounds(800, 30, 120, 60);
        add(backButton);

        JButton addButton = new JButton("添加教师读者");
        addButton.setBounds(80, 120, 100, 50);
        add(addButton);

        JButton alterButton = new JButton("修改教师读者信息");
        alterButton.setBounds(80, 200, 100, 50);
        add(alterButton);

        JButton borrowButton = new JButton("帮助借书");
        borrowButton.setBounds(80, 280, 100, 50);
        add(borrowButton);

        JButton returnButton = new JButton("帮助还书");
        returnButton.setBounds(80, 360, 100, 50);
        add(returnButton);


        // 创建表格
        tableModel = new DefaultTableModel();
        tableModel.addColumn("姓名");
        tableModel.addColumn("性别");
        tableModel.addColumn("年龄");
        tableModel.addColumn("院系");
        tableModel.addColumn("工号");
        tableModel.addColumn("密码");
        table = new JTable(tableModel);

        // 添加数据
        teacher_service teacher_service_mapper=new teacher_serviceImpl();
        List<teacher> teachers=teacher_service_mapper.find_all_teacher();
        for(teacher item:teachers){
            Object[]row={item.get_name(),item.get_sex(),item.getAge(),item.getDept(),
                    item.get_id(),item.get_password()};
            tableModel.addRow(row);

        }

        // 创建滚动窗格
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(250, 120, 600, 350);
        add(scrollPane);

        //获取表格选中行的元素
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        name = table.getValueAt(selectedRow, 0).toString();
                        sex = table.getValueAt(selectedRow, 1).toString();
                        age = table.getValueAt(selectedRow, 2).toString();
                        college = table.getValueAt(selectedRow, 3).toString();
                        id = table.getValueAt(selectedRow, 4).toString();
                        password = table.getValueAt(selectedRow, 5).toString();
                    }
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Library_manage frame = new Library_manage();
                frame.setVisible(true);
            }
        });

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                teacher_info frame = new teacher_info("", "", "", "", "", "");
                frame.setVisible(true);
            }
        });

        borrowButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Library_borrow frame = new Library_borrow();
                frame.setVisible(true);
            }
        });

        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Library_return frame = new Library_return();
                frame.setVisible(true);
            }
        });

        alterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                teacher_info frame = new teacher_info(name, sex, age, college, id, password);
                frame.setVisible(true);
            }
        });

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(table.getModel());
                sorter.setRowFilter(RowFilter.regexFilter(searchField.getText()));
                table.setRowSorter(sorter);
            }
        });

    }

    public static void main(String[] args) {
        Library_teacher_manage frame = new Library_teacher_manage();
        frame.setVisible(true);
    }
}

