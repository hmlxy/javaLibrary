package org.library.view;

import org.library.pojo.*;

import org.library.dao.*;
import org.library.pojo.*;
import org.library.service.*;
import org.library.service.impl.book_serviceImpl;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class teacher_manage extends JFrame {
    private teacher teacher;
    public teacher_manage() {
        setTitle("图书管理系统");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);//绝对布局

        JLabel label = new JLabel("读者界面");
        label.setFont(new Font("宋体", Font.BOLD, 50));
        label.setBounds(100, 50, 300, 100);
        add(label);

        JButton backButton = new JButton("返回登录");
        backButton.setBounds(800, 50, 120, 60);
        add(backButton);

        JButton infoButton = new JButton("查看个人信息");
        infoButton.setBounds(100, 200, 200, 50);
        add(infoButton);

        JButton borrowButton = new JButton("查询个人借阅信息");
        borrowButton.setBounds(100, 300, 200, 50);
        add(borrowButton);

        JButton bookButton = new JButton("查询图书");
        bookButton.setBounds(100, 400, 200, 50);
        add(bookButton);


        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Login frame = new Login();
                frame.setVisible(true);
            }
        });

        infoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                teacher_info frame = new teacher_info(teacher.get_name(),teacher.get_sex(),teacher.getAge(),
                        teacher.getDept(),teacher.get_id(),teacher.get_password());
                frame.setVisible(true);
            }
        });

        borrowButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                User_borrow frame = new User_borrow();
                frame.setUser_id(teacher.get_id());
                frame.setVisible(true);
            }
        });

        bookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                User_book frame = new User_book();

                frame.setVisible(true);
            }
        });
    }

    public  void set_teacher(teacher teacher){
        this.teacher=teacher;
    }

    public static void main(String[] args) {
        teacher_manage frame = new teacher_manage();
        frame.setVisible(true);
    }
}
