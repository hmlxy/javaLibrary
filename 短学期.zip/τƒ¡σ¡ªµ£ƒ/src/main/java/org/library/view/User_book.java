package org.library.view;

import org.library.pojo.book;
import org.library.service.book_service;
import org.library.service.impl.book_serviceImpl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class User_book extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    public  User_book() {
        setTitle("图书管理系统");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);//绝对布局

        JLabel label = new JLabel("图书查询");
        label.setFont(new Font("宋体", Font.BOLD, 30));
        label.setBounds(50, 30, 300, 80);
        add(label);

        JTextField searchField = new JTextField();
        searchField.setBounds(300, 50, 300, 50);
        add(searchField);

        JButton searchButton = new JButton("查询");
        searchButton.setBounds(620, 50, 100, 50);
        add(searchButton);

        JButton backButton = new JButton("返回");
        backButton.setBounds(800, 30, 120, 60);
        add(backButton);



        // 创建表格
        tableModel = new DefaultTableModel();
        tableModel.addColumn("书名");
        tableModel.addColumn("作者");
        tableModel.addColumn("分类");
        tableModel.addColumn("出版社");
        tableModel.addColumn("出版年份");
        tableModel.addColumn("借阅状态");
        table = new JTable(tableModel);

        // 添加数据
        book_service book_service_mapper=new book_serviceImpl();
        List<book> books=book_service_mapper.find_all_book();
        for(book item:books){
            Object[] row={item.get_name(),item.get_author(),item.get_category(),
                    item.get_publisher(),item.get_year(),item.get_status(),item.get_brodate(),item.get_returndate()};
            tableModel.addRow(row);
        }

        // 创建滚动窗格
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 120, 800, 400);
        add(scrollPane);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                teacher_manage frame = new teacher_manage();
                frame.setVisible(true);
            }
        });


        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(table.getModel());
                sorter.setRowFilter(RowFilter.regexFilter(searchField.getText()));
                table.setRowSorter(sorter);
            }
        });

    }

    public static void main(String[] args) {
        User_book frame = new User_book();
        frame.setVisible(true);
    }
}
