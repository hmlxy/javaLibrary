package org.library.view;

import org.library.pojo.student;
import org.library.pojo.teacher;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class student_manage extends JFrame {
    private student student;

    public student_manage() {
        setTitle("图书管理系统");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);//绝对布局

        JLabel label = new JLabel("读者界面");
        label.setFont(new Font("宋体", Font.BOLD, 50));
        label.setBounds(100, 50, 300, 100);
        add(label);

        JButton backButton = new JButton("返回登录");
        backButton.setBounds(800, 50, 120, 60);
        add(backButton);

        JButton infoButton = new JButton("查看个人信息");
        infoButton.setBounds(100, 200, 200, 50);
        add(infoButton);

        JButton borrowButton = new JButton("查询个人借阅信息");
        borrowButton.setBounds(100, 300, 200, 50);
        add(borrowButton);

        JButton bookButton = new JButton("查询图书");
        bookButton.setBounds(100, 400, 200, 50);
        add(bookButton);


        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Login frame = new Login();
                frame.setVisible(true);
            }
        });

        infoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                student_info frame = new student_info(student.get_name(),student.get_sex(),student.getAge(),
                        student.getDept(),student.get_id(),student.get_password());
                frame.setVisible(true);
            }
        });

        borrowButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                User_borrow frame = new User_borrow();
                frame.setUser_id(student.get_id());
                frame.setVisible(true);
            }
        });

        bookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                User_book frame = new User_book();
                frame.setVisible(true);
            }
        });
    }


    public  void set_student(student student){
        this.student=student;
    }
    public static void main(String[] args) {
        student_manage frame = new student_manage();
        frame.setVisible(true);
    }
}
