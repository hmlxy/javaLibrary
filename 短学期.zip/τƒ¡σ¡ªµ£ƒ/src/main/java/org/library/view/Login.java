package org.library.view;

import org.library.service.*;
import org.library.service.impl.library_manager_serviceImpl;
import org.library.service.impl.student_serviceImpl;
import org.library.service.impl.system_manager_serviceImpl;
import org.library.pojo.*;
import org.library.service.impl.teacher_serviceImpl;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.NoSuchAlgorithmException;

public class Login extends JFrame {
    public Login() {
        setTitle("图书管理系统");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);//绝对布局

        JLabel label = new JLabel("图书管理系统");
        label.setFont(new Font("宋体", Font.BOLD, 24));
        label.setBounds(120, 20, 200, 50);
        add(label);

        JLabel userLabel = new JLabel("工号/学号：");
        userLabel.setBounds(50, 100, 80, 30);
        add(userLabel);

        JTextField userField = new JTextField();
        userField.setBounds(120, 100, 200, 30);
        add(userField);

        JLabel passwordLabel = new JLabel("密   码：");
        passwordLabel.setBounds(50, 150, 80, 30);
        add(passwordLabel);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(120, 150, 200, 30);
        add(passwordField);

        JButton loginButton = new JButton("登录");
        loginButton.setBounds(150, 300, 80, 30);
        add(loginButton);

        // 创建单选框
        JRadioButton systemButton = new JRadioButton("系统管理员");
        JRadioButton libraryButton = new JRadioButton("图书管理员");
        JRadioButton studentButton = new JRadioButton("学生");
        JRadioButton teacherButton = new JRadioButton("老师");

        systemButton.setBounds(50,220,120,30);
        libraryButton.setBounds(200,220,120,30);
        studentButton.setBounds(50,250,120,30);
        teacherButton.setBounds(200,250,120,30);

        // 创建按钮组，并将单选框添加到按钮组中
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(systemButton);
        buttonGroup.add(libraryButton);
        buttonGroup.add(studentButton);
        buttonGroup.add(teacherButton);

        add(systemButton);
        add(libraryButton);
        add(studentButton);
        add(teacherButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                String id = userField.getText();
                String password=passwordField.getText();
                if(systemButton.isSelected()){
                   system_manager_service system_manager_mapper=new system_manager_serviceImpl();
                    try {
                        boolean log=system_manager_mapper.system_manager_login(id,password);
                        if(log){
                            System_manage frame = new System_manage();
                            frame.setVisible(true);
                        }
                        else{
                            JOptionPane.showMessageDialog(null, "用户名或密码不正确!!!");
                            setVisible(true);
                        }
                    } catch (NoSuchAlgorithmException ex) {
                        throw new RuntimeException(ex);
                    }

                }
                if(libraryButton.isSelected()){
                    library_manager_service library_manager_mapper=new library_manager_serviceImpl();
                    try {
                        boolean log=library_manager_mapper.library_manager_login(id,password);
                        library_manager library_manager= library_manager_mapper.find_library_manager_by_id(id);
                        if(log){
                            Library_manage frame = new Library_manage();
                            frame.set_Library_manager(library_manager);
                            frame.setVisible(true);
                        }
                        else{
                            JOptionPane.showMessageDialog(null, "用户名或密码不正确!!!");
                            setVisible(true);
                        }
                    } catch (NoSuchAlgorithmException ex) {
                        throw new RuntimeException(ex);
                    }

                }
                if(studentButton.isSelected()){
                    student_service student_mapper=new student_serviceImpl();
                    try {
                        boolean log=student_mapper.student_login(id,password);
                        student student= student_mapper.find_student_by_id(id);
                        if(log){
                            student_manage frame = new student_manage();
                            frame.set_student(student);
                            frame.setVisible(true);
                        }
                        else{
                            JOptionPane.showMessageDialog(null, "用户名或密码不正确!!!");
                            setVisible(true);
                        }
                    } catch (NoSuchAlgorithmException ex) {
                        throw new RuntimeException(ex);
                    }
                }
                if(teacherButton.isSelected()){
                    teacher_service teacher_mapper=new teacher_serviceImpl();
                    try {
                        boolean log=teacher_mapper.teacher_login(id,password);
                        teacher teacher= teacher_mapper.find_teacher_by_id(id);
                        if(log){
                            teacher_manage frame = new teacher_manage();
                            frame.set_teacher(teacher);
                            frame.setVisible(true);
                        }
                        else{
                            JOptionPane.showMessageDialog(null, "用户名或密码不正确!!!");
                            setVisible(true);
                        }
                    } catch (NoSuchAlgorithmException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });


    }

    public static void main(String[] args) {
        Login frame = new Login();
        frame.setVisible(true);
    }
}
