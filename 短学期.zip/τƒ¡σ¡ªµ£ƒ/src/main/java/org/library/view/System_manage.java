package org.library.view;

import org.apache.ibatis.session.SqlSession;
import org.library.dao.*;
import org.library.pojo.*;
import org.library.service.*;
import org.library.service.impl.library_manager_serviceImpl;
import org.library.service.impl.system_manager_serviceImpl;
import org.library.utils.MybatisUtils;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class System_manage extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    public static String name="";
    public static String sex="";
    public static String id="";
    public static String password="";
    public static String telephone="";
    public static String power="";
    public  System_manage() {
        setTitle("图书管理系统");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);//绝对布局

        JLabel label = new JLabel("系统管理员界面");
        label.setFont(new Font("宋体", Font.BOLD, 30));
        label.setBounds(50, 30, 300, 80);
        add(label);

        JTextField searchField = new JTextField();
        searchField.setBounds(400, 50, 200, 50);
        add(searchField);

        JButton searchButton = new JButton("查询");
        searchButton.setBounds(620, 50, 100, 50);
        add(searchButton);

        JButton backButton = new JButton("返回登录");
        backButton.setBounds(800, 30, 120, 60);
        add(backButton);

        JButton addButton = new JButton("添加");
        addButton.setBounds(80, 120, 100, 50);
        add(addButton);

        JButton alterButton = new JButton("修改");
        alterButton.setBounds(80, 200, 100, 50);
        add(alterButton);

        JButton deleteButton = new JButton("删除");
        deleteButton.setBounds(80, 280, 100, 50);
        add(deleteButton);


        // 创建表格
        tableModel = new DefaultTableModel();
        tableModel.addColumn("姓名");
        tableModel.addColumn("性别");
        tableModel.addColumn("工号");
        tableModel.addColumn("密码");
        tableModel.addColumn("电话");
        table = new JTable(tableModel);

        // 添加数据
        library_manager_service library_manager_mapper=new library_manager_serviceImpl();

        List<library_manager> library_managers=  library_manager_mapper.find_all_library_manager();

        for(library_manager item :library_managers){
            Object[] row={item.get_id(),item.get_sex(),item.get_name(),item.get_password(),item.get_phone()};
            tableModel.addRow(row);
        }

        // 创建滚动窗格
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(250, 120, 600, 350);
        add(scrollPane);

        //获取表格选中行的元素
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        id = table.getValueAt(selectedRow, 0).toString();
                        sex = table.getValueAt(selectedRow, 1).toString();
                        name = table.getValueAt(selectedRow, 2).toString();
                        password = table.getValueAt(selectedRow, 3).toString();
                        telephone = table.getValueAt(selectedRow, 4).toString();
                    }
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Login frame = new Login();
                frame.setVisible(true);
            }
        });

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System_info frame = new System_info("", "", "", "", "", "");
                frame.setVisible(true);
            }
        });

        alterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System_info frame = new System_info(name, sex, power, id, password, telephone);
                frame.setVisible(true);
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              library_manager_service library_manager_mapper=new library_manager_serviceImpl();
              library_manager_mapper.delete_library_manager_by_id(id);
            }
        });

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                System.out.println(searchField.getText().equals(""));
                if(searchField.getText().equals("")){
                    tableModel.setRowCount(0);
                    library_manager_service library_manager_mapper=new library_manager_serviceImpl();

                    List<library_manager> library_managers=  library_manager_mapper.find_all_library_manager();

                    for(library_manager item :library_managers){
                        Object[] row={item.get_id(),item.get_sex(),item.get_name(),item.get_password(),item.get_phone()};
                        tableModel.addRow(row);
                    }
                }
                else{
                    TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(table.getModel());
                    sorter.setRowFilter(RowFilter.regexFilter(searchField.getText()));
                    table.setRowSorter(sorter);
                }

            }
        });

    }

    public static void main(String[] args) {
        System_manage frame = new System_manage();
        frame.setVisible(true);
    }
}
