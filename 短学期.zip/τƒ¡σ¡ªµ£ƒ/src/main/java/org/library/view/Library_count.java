package org.library.view;

import org.apache.ibatis.session.SqlSession;
import org.library.dao.*;
import org.library.pojo.*;
import org.library.service.*;
import org.library.service.impl.book_serviceImpl;
import org.library.service.impl.library_manager_serviceImpl;
import org.library.service.impl.system_manager_serviceImpl;
import org.library.utils.MybatisUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Library_count extends JFrame{
    public Library_count(JTable table){
        setTitle("图书管理系统");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setLayout(null);//绝对布局

        JTextField nameField = new JTextField();
        nameField.setBounds(50, 80, 100, 30);
        add(nameField);

        JButton nameButton = new JButton("书名统计");
        nameButton.setBounds(160,80,100,30);
        add(nameButton);

        JTextField categoryField = new JTextField();
        categoryField.setBounds(300, 80, 100, 30);
        add(categoryField);

        JButton categoryButton = new JButton("分类统计");
        categoryButton.setBounds(410,80,100,30);
        add(categoryButton);

        JTextField authorField = new JTextField();
        authorField.setBounds(50, 130, 100, 30);
        add(authorField);

        JButton authorButton = new JButton("作者统计");
        authorButton.setBounds(160,130,100,30);
        add(authorButton);

        JLabel countLabel = new JLabel("统计结果:");
        countLabel.setBounds(50,200,80,30);
        add(countLabel);

        JTextField countField = new JTextField();
        countField.setBounds(130, 200, 100, 30);
        add(countField);

        JButton backButton = new JButton("返回");
        backButton.setBounds(300, 200, 100, 30);
        add(backButton);

        nameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int count = 0;
                book_service book_service_mapper=new book_serviceImpl();
                count=book_service_mapper.get_count_by_name(nameField.getText());
                countField.setText(String.valueOf(count));
            }
        });

        categoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int count = 0;
                book_service book_service_mapper=new book_serviceImpl();
                count=book_service_mapper.get_count_by_category(categoryField.getText());
                countField.setText(String.valueOf(count));
            }
        });

        authorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int count = 0;
                book_service book_service_mapper=new book_serviceImpl();
                count=book_service_mapper.get_count_by_author(authorField.getText());
                countField.setText(String.valueOf(count));
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
    }

    public static void main(String[] args) {
        JTable table=new JTable();
        Library_count frame = new Library_count(table);
        frame.setVisible(true);
    }
}
