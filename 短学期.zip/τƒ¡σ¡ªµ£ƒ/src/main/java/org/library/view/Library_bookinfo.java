package org.library.view;

import org.apache.ibatis.session.SqlSession;
import org.library.dao.*;
import org.library.pojo.*;
import org.library.service.*;
import org.library.service.impl.*;
import org.library.utils.MybatisUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Library_bookinfo extends JFrame{
    public Library_bookinfo(String id,String name,String author,String category,String place,String publisher,String year,String status,String user){
        setTitle("图书管理系统");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setLayout(null);//绝对布局

        JLabel label = new JLabel("图书信息");
        label.setFont(new Font("宋体", Font.BOLD, 24));
        label.setBounds(250, 30, 200, 50);
        add(label);

        JLabel idLabel = new JLabel("编号:");
        idLabel.setBounds(50, 80, 40, 30);
        add(idLabel);

        JTextField idField = new JTextField();
        idField.setBounds(90, 80, 100, 30);
        idField.setText(id);
        add(idField);

        JLabel nameLabel = new JLabel("书名:");
        nameLabel.setBounds(200, 80, 40, 30);
        add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(240, 80, 100, 30);
        nameField.setText(name);
        add(nameField);

        JLabel authorLabel = new JLabel("作者:");
        authorLabel.setBounds(360, 80, 40, 30);
        add(authorLabel);

        JTextField authorField = new JTextField();
        authorField.setBounds(400, 80, 100, 30);
        authorField.setText(author);
        add(authorField);

        JLabel categoryLabel = new JLabel("分类:");
        categoryLabel.setBounds(50, 130, 40, 30);
        add(categoryLabel);

        JTextField categoryField = new JTextField();
        categoryField.setBounds(90, 130, 100, 30);
        categoryField.setText(category);
        add(categoryField);

        JLabel placeLabel = new JLabel("位置:");
        placeLabel.setBounds(200, 130, 40, 30);
        add(placeLabel);

        JTextField placeField = new JTextField();
        placeField.setBounds(240, 130, 100, 30);
        placeField.setText(place);
        add(placeField);


        JLabel publisherLabel = new JLabel("出版社:");
        publisherLabel.setBounds(360, 130, 50, 30);
        add(publisherLabel);

        JTextField publisherField = new JTextField();
        publisherField.setBounds(400, 130, 100, 30);
        publisherField.setText(publisher);
        add(publisherField);

        JLabel yearLabel = new JLabel("出版年份:");
        yearLabel.setBounds(40, 180, 60, 30);
        add(yearLabel);

        JTextField yearField = new JTextField();
        yearField.setBounds(100, 180, 100, 30);
        yearField.setText(year);
        add(yearField);

        JLabel statusLabel = new JLabel("借阅状态:");
        statusLabel.setBounds(220, 180, 60, 30);
        add(statusLabel);

        JTextField statusField = new JTextField();
        statusField.setBounds(280, 180, 100, 30);
        statusField.setText(status);
        add(statusField);

        JLabel userLabel = new JLabel("借阅人:");
        userLabel.setBounds(400, 180, 60, 30);
        add(userLabel);

        JTextField userField = new JTextField();
        userField.setBounds(460, 180, 100, 30);
        userField.setText(user);
        add(userField);


        JButton backButton = new JButton("取消");
        backButton.setBounds(100, 280, 80, 40);
        add(backButton);

        JButton addButton = new JButton("添加");
        addButton.setBounds(250, 280, 80, 40);
        add(addButton);

        JButton setButton = new JButton("保存");
        setButton.setBounds(400, 280, 80, 40);
        add(setButton);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                book book=new book();
                book.set_all(idField.getText(),nameField.getText(),authorField.getText(),
                        categoryField.getText(),placeField.getText(),publisherField.getText(),
                        yearField.getText(),statusField.getText());
                book_service book_service_mapper=new book_serviceImpl();
                book_service_mapper.add_book(book);
            }
        });

        setButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                book book=new book();
                int borrow_time=0;
                String status=null;
                student_service student_service_mapper=new student_serviceImpl();
                teacher_service teacher_service_mapper=new teacher_serviceImpl();
                if(student_service_mapper.find_student_by_id(userField.getText())!=null){
                    borrow_time=30;
                    System.out.println(1);
                    status="已借出";
                }
                else if(teacher_service_mapper.find_teacher_by_id(userField.getText())!=null){
                    borrow_time=60;
                    System.out.println(2);
                    status="已借出";
                }
                else {
                    System.out.println(3);
                }
                book.set_all(idField.getText(),nameField.getText(),authorField.getText(),
                        categoryField.getText(),placeField.getText(),publisherField.getText(),
                        yearField.getText(),status,userField.getText(),borrow_time);
                book_service book_service_mapper=new book_serviceImpl();
                book_service_mapper.update_book(book);
                System.out.println(book_service_mapper.update_book(book));
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

    }

    public static void main(String[] args) {
        Library_bookinfo frame = new Library_bookinfo("","","","","","","","","");
        frame.setVisible(true);
    }
}
