package org.library.view;

import org.apache.ibatis.session.SqlSession;
import org.library.dao.*;
import org.library.pojo.*;
import org.library.service.*;
import org.library.service.impl.book_serviceImpl;
import org.library.service.impl.library_manager_serviceImpl;
import org.library.service.impl.system_manager_serviceImpl;
import org.library.utils.MybatisUtils;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Library_book extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    public static String id="";
    public static String name="";
    public static String author="";
    public static String category="";//分类
    public static String place="";
    public static String publisher="";//出版社
    public static String year="";
    public static String status="";//借阅状态

    public static String user="";//用户ID
    public  Library_book() {
        setTitle("图书管理系统");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);//绝对布局

        JLabel label = new JLabel("图书管理员界面");
        label.setFont(new Font("宋体", Font.BOLD, 30));
        label.setBounds(50, 30, 300, 80);
        add(label);

        JTextField searchField = new JTextField();
        searchField.setBounds(400, 50, 200, 50);
        add(searchField);

        JButton searchButton = new JButton("查询");
        searchButton.setBounds(620, 50, 100, 50);
        add(searchButton);

        JButton backButton = new JButton("返回");
        backButton.setBounds(800, 30, 120, 60);
        add(backButton);

        JButton addButton = new JButton("添加");
        addButton.setBounds(80, 120, 100, 50);
        add(addButton);

        JButton alterButton = new JButton("修改");
        alterButton.setBounds(80, 200, 100, 50);
        add(alterButton);

        JButton deleteButton = new JButton("删除");
        deleteButton.setBounds(80, 280, 100, 50);
        add(deleteButton);

        JButton countButton = new JButton("统计");
        countButton.setBounds(80, 360, 100, 50);
        add(countButton);


        // 创建表格
        tableModel = new DefaultTableModel();
        tableModel.addColumn("图书编号");
        tableModel.addColumn("图书名称");
        tableModel.addColumn("作者");
        tableModel.addColumn("分类");
        tableModel.addColumn("位置");
        tableModel.addColumn("出版社");
        tableModel.addColumn("出版年份");
        tableModel.addColumn("借阅状态");
        tableModel.addColumn("借阅人");
        table = new JTable(tableModel);

        // 添加数据
        book_service book_service_mapper=new book_serviceImpl();
        List<book> books=book_service_mapper.find_all_book();
        for(book item:books){
            Object[] row={item.get_id(),item.get_name(),item.get_author(),item.get_category(),
                    item.get_place(),item.get_publisher(),item.get_year(),item.get_status(),item.get_uid()};
            tableModel.addRow(row);
        }


        // 创建滚动窗格
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(250, 120, 700, 350);
        add(scrollPane);

        //获取表格选中行的元素
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        id = table.getValueAt(selectedRow, 0).toString();
                        name = table.getValueAt(selectedRow, 1).toString();
                        author = table.getValueAt(selectedRow, 2).toString();
                        category = table.getValueAt(selectedRow, 3).toString();
                        place=table.getValueAt(selectedRow,4).toString();
                        publisher = table.getValueAt(selectedRow, 5).toString();
                        year = table.getValueAt(selectedRow, 6).toString();
                        status = table.getValueAt(selectedRow, 7).toString();
                        if(table.getValueAt(selectedRow,8)!=null){
                            user=table.getValueAt(selectedRow,8).toString();
                        }
                        else{
                            user=null;
                        }

                    }
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Library_manage frame = new Library_manage();
                frame.setVisible(true);
            }
        });

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Library_bookinfo frame = new Library_bookinfo("","","","","",
                        "","","","");
                frame.setVisible(true);
            }
        });

        alterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Library_bookinfo frame = new Library_bookinfo(id,name,author,category,place,publisher,year,status,user);
                frame.setVisible(true);
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              book_service book_service_mapper=new book_serviceImpl();
              book_service_mapper.delete_book_by_id(id);
            }
        });

        countButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Library_count frame = new Library_count(table);
                frame.setVisible(true);
            }
        });

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                if(searchField.getText().equals("")){
                    tableModel.setRowCount(0);
                    book_service book_service_mapper=new book_serviceImpl();
                    List<book> books=book_service_mapper.find_all_book();
                    for(book item:books){
                        Object[] row={item.get_id(),item.get_name(),item.get_author(),item.get_category(),
                                item.get_place(),item.get_publisher(),item.get_year(),item.get_status()};
                        tableModel.addRow(row);
                    }
                }
                else{
                    TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(table.getModel());
                    sorter.setRowFilter(RowFilter.regexFilter(searchField.getText()));
                    table.setRowSorter(sorter);
                }

            }
        });

    }

    public static void main(String[] args) {
        Library_book frame = new Library_book();
        frame.setVisible(true);
    }
}
