package org.library.view;

import org.apache.ibatis.session.SqlSession;
import org.library.dao.*;
import org.library.pojo.*;
import org.library.service.*;
import org.library.service.impl.library_manager_serviceImpl;
import org.library.service.impl.system_manager_serviceImpl;
import org.library.utils.MybatisUtils;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class System_info extends JFrame{
    public System_info(String name,String sex,String power,String id,String password,String telephone){
        setTitle("图书管理系统");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setLayout(null);//绝对布局

        JLabel label = new JLabel("用户信息");
        label.setFont(new Font("宋体", Font.BOLD, 24));
        label.setBounds(250, 30, 200, 50);
        add(label);

        JLabel nameLabel = new JLabel("姓名:");
        nameLabel.setBounds(50, 80, 40, 30);
        add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(90, 80, 100, 30);
        nameField.setText(name);
        add(nameField);

        JLabel sexLabel = new JLabel("性别:");
        sexLabel.setBounds(200, 80, 40, 30);
        add(sexLabel);

        JTextField sexField = new JTextField();
       sexField.setBounds(240, 80, 100, 30);
       sexField.setText(sex);
        add(sexField);

        JLabel powerLabel = new JLabel("权限:");
        powerLabel.setBounds(360, 80, 40, 30);
        add(powerLabel);

        JTextField powerField = new JTextField();
        powerField.setBounds(400, 80, 100, 30);
        powerField.setText(power);
        add(powerField);

        JLabel idLabel = new JLabel("工号:");
        idLabel.setBounds(50, 130, 40, 30);
        add(idLabel);

        JTextField idField = new JTextField();
        idField.setBounds(90, 130, 400, 30);
        idField.setText(id);
        add(idField);

        JLabel passwordLabel = new JLabel("密码:");
        passwordLabel.setBounds(50, 180, 40, 30);
        add(passwordLabel);

        JTextField passwordField = new JTextField();
        passwordField.setBounds(90, 180, 400, 30);
        passwordField.setText(password);
        add(passwordField);

        JLabel telephoneLabel = new JLabel("电话:");
        telephoneLabel.setBounds(50, 230, 40, 30);
        add(telephoneLabel);

        JTextField telephoneField = new JTextField();
        telephoneField.setBounds(90, 230, 400, 30);
        telephoneField.setText(telephone);
        add(telephoneField);

        JButton backButton = new JButton("取消");
        backButton.setBounds(100, 280, 80, 40);
        add(backButton);

        JButton addButton = new JButton("添加");
        addButton.setBounds(250, 280, 80, 40);
        add(addButton);

        JButton setButton = new JButton("保存");
        setButton.setBounds(400, 280, 80, 40);
        add(setButton);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                library_manager library_manager=new library_manager();
                library_manager.set_id(idField.getText());
                library_manager.set_sex(sexField.getText());
                library_manager.set_name(nameField.getText());
                library_manager.set_password(passwordField.getText());
                library_manager.set_phone(telephoneField.getText());
                library_manager_service library_manager_mapper=new library_manager_serviceImpl();
                library_manager_mapper.add_library_manager(library_manager);
            }
        });

        setButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                library_manager library_manager=new library_manager();
                library_manager.set_id(idField.getText());
                library_manager.set_sex(sexField.getText());
                library_manager.set_name(nameField.getText());
                library_manager.set_password(passwordField.getText());
                library_manager.set_phone(telephoneField.getText());
                library_manager_service library_manager_mapper=new library_manager_serviceImpl();
                System.out.println(library_manager_mapper.update_library_manager(library_manager));
                System.out.println(library_manager_mapper.find_library_manager_by_id(library_manager.get_id()));
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
    }


    public static void main(String[] args) {
        System_info frame = new System_info("","","","","","");
        frame.setVisible(true);
    }


}
