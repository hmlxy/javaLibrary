package org.library.view;

import org.library.pojo.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Library_manage extends JFrame {

    private library_manager library_manager;
    public  Library_manage() {
        setTitle("图书管理系统");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);//绝对布局

        JLabel label = new JLabel("图书管理员界面");
        label.setFont(new Font("宋体", Font.BOLD, 50));
        label.setBounds(100, 50, 400, 100);
        add(label);

        JButton backButton = new JButton("返回登录");
        backButton.setBounds(800, 50, 120, 60);
        add(backButton);

        JButton infoButton = new JButton("修改个人信息");
        infoButton.setBounds(100, 200, 200, 50);
        add(infoButton);

        JButton studentButton = new JButton("管理学生");
        studentButton.setBounds(100, 300, 200, 50);
        add(studentButton);

        JButton teacherButton = new JButton("管理老师");
        teacherButton.setBounds(100, 400, 200, 50);
        add(teacherButton);

        JButton bookButton = new JButton("管理图书");
        bookButton.setBounds(100, 500, 200, 50);
        add(bookButton);


        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Login frame = new Login();
                frame.setVisible(true);
            }
        });

        infoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                student_info frame = new student_info(library_manager.get_name(),library_manager.get_sex()
                        ,"","",library_manager.get_id(),library_manager.get_password());
                frame.setVisible(true);
            }
        });

        studentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Library_student_manage frame = new Library_student_manage();
                frame.setVisible(true);
            }
        });

         teacherButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Library_teacher_manage frame = new Library_teacher_manage();
                frame.setVisible(true);
            }
        });

        bookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Library_book frame = new Library_book();
                frame.setVisible(true);
            }
        });
    }

    public void set_Library_manager(library_manager library_manager){
        this.library_manager=library_manager;
    }
    public static void main(String[] args) {
        Library_manage frame = new Library_manage();
        frame.setVisible(true);
    }
}
