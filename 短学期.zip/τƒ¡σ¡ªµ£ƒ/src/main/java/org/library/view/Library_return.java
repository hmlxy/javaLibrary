package org.library.view;

import org.library.pojo.book;
import org.library.service.book_service;
import org.library.service.impl.book_serviceImpl;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Library_return extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;

    public static String id="";
    public static String name="";
    public static String author="";
    public static String category="";//分类
    public static String place="";
    public static String publisher="";//出版社
    public static String year="";
    public static String status="";//借阅状态

    public Library_return() {

        setTitle("图书管理系统");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);//绝对布局

        JLabel label = new JLabel("图书归还");
        label.setFont(new Font("宋体", Font.BOLD, 30));
        label.setBounds(50, 30, 300, 80);
        add(label);

        JButton ascendButton = new JButton("归还时间升序");
        ascendButton.setBounds(300, 30, 150, 50);
        add(ascendButton);

        JButton descendButton = new JButton("归还时间降序");
        descendButton.setBounds(500, 30, 150, 50);
        add(descendButton);

        JButton backButton = new JButton("返回");
        backButton.setBounds(800, 30, 120, 60);
        add(backButton);

        JButton returnButton = new JButton("帮助还书");
        returnButton.setBounds(50, 450, 120, 60);
        add(returnButton);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("编号");
        tableModel.addColumn("书名");
        tableModel.addColumn("作者");
        tableModel.addColumn("分类");
        tableModel.addColumn("位置");
        tableModel.addColumn("出版社");
        tableModel.addColumn("出版年份");
        tableModel.addColumn("借阅状态");
        tableModel.addColumn("借阅日期");
        tableModel.addColumn("归还日期");
        table = new JTable(tableModel);

        // 添加数据
        book_service book_service_mapper=new book_serviceImpl();
        List<book> books=book_service_mapper.find_all_book();
        for(book item:books){
            Object[] row={item.get_id(),item.get_name(),item.get_author(),item.get_category(),
                    item.get_place(),item.get_publisher(),item.get_year(),item.get_status(),item.get_brodate(),item.get_returndate()};
            tableModel.addRow(row);
        }

        // 创建滚动窗格
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 120, 800, 300);
        add(scrollPane);


        //剩余时间升序
        ascendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        //剩余时间降序
        descendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Library_student_manage frame = new Library_student_manage();
                frame.setVisible(true);
            }
        });

        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        id = table.getValueAt(selectedRow, 0).toString();
                        name = table.getValueAt(selectedRow, 1).toString();
                        author = table.getValueAt(selectedRow, 2).toString();
                        category = table.getValueAt(selectedRow, 3).toString();
                        place=table.getValueAt(selectedRow,4).toString();
                        publisher = table.getValueAt(selectedRow, 5).toString();
                        year = table.getValueAt(selectedRow, 6).toString();
                        status = table.getValueAt(selectedRow, 7).toString();

                    }
                }
            }
        });
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                book_service book_service_mapper=new book_serviceImpl();
                book book=new book();
                book.set_all(id,name,author,category,place,publisher,year,status);
                book_service_mapper.update_return_book(book);
            }
        });

        ascendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tableModel.setRowCount(0);
                book_service book_service_mapper=new book_serviceImpl();
                List<book> books=book_service_mapper.find_all_book_by_ASC();
                for(book item:books){
                    Object[] row={item.get_id(),item.get_name(),item.get_author(),item.get_category(),
                            item.get_place(),item.get_publisher(),item.get_year(),item.get_status(),item.get_brodate(),item.get_returndate()};
                    tableModel.addRow(row);
                }
            }
        });

        descendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tableModel.setRowCount(0);
                book_service book_service_mapper=new book_serviceImpl();
                List<book> books=book_service_mapper.find_all_book_by_DESC();
                for(book item:books){
                    Object[] row={item.get_id(),item.get_name(),item.get_author(),item.get_category(),
                            item.get_place(),item.get_publisher(),item.get_year(),item.get_status(),item.get_brodate(),item.get_returndate()};
                    tableModel.addRow(row);
                }
            }
        });
    }



    public static void main(String[] args) {
        Library_return frame = new Library_return();
        frame.setVisible(true);
    }
}
