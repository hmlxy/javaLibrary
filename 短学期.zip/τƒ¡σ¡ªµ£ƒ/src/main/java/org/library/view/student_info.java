package org.library.view;

import org.apache.ibatis.session.SqlSession;
import org.library.dao.*;
import org.library.pojo.*;
import org.library.service.*;
import org.library.service.impl.*;
import org.library.utils.MybatisUtils;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class student_info extends JFrame{
    public student_info(String name, String sex, String age, String college, String id, String password){
        setTitle("图书管理系统");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setLayout(null);//绝对布局

        JLabel label = new JLabel("用户信息");
        label.setFont(new Font("宋体", Font.BOLD, 24));
        label.setBounds(250, 30, 200, 50);
        add(label);

        JLabel nameLabel = new JLabel("姓名:");
        nameLabel.setBounds(50, 80, 40, 30);
        add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(90, 80, 100, 30);
        nameField.setText(name);
        add(nameField);

        JLabel sexLabel = new JLabel("性别:");
        sexLabel.setBounds(350, 80, 40, 30);
        add(sexLabel);

        JTextField sexField = new JTextField();
        sexField.setBounds(390, 80, 100, 30);
        sexField.setText(sex);
        add(sexField);

        JLabel ageLabel = new JLabel("年龄:");
        ageLabel.setBounds(50, 130, 40, 30);
        add(ageLabel);

        JTextField ageField = new JTextField();
        ageField.setBounds(90, 130, 100, 30);
        ageField.setText(age);
        add(ageField);

        JLabel collegeLabel = new JLabel("院系:");
        collegeLabel.setBounds(250, 130, 40, 30);
        add(collegeLabel);

        JTextField collegeField = new JTextField();
        collegeField.setBounds(290, 130, 200, 30);
        collegeField.setText(college);
        add(collegeField);

        JLabel idLabel = new JLabel("工号:");
        idLabel.setBounds(50, 180, 40, 30);
        add(idLabel);

        JTextField idField = new JTextField();
        idField.setBounds(90, 180, 400, 30);
        idField.setText(id);
        add(idField);

        JLabel passwordLabel = new JLabel("密码:");
        passwordLabel.setBounds(50, 230, 40, 30);
        add(passwordLabel);

        JTextField passwordField = new JTextField();
        passwordField.setBounds(90, 230, 400, 30);
        passwordField.setText(password);
        add(passwordField);

        JButton backButton = new JButton("取消");
        backButton.setBounds(100, 280, 80, 40);
        add(backButton);

        JButton addButton = new JButton("添加");
        addButton.setBounds(250, 280, 80, 40);
        add(addButton);

        JButton setButton = new JButton("保存");
        setButton.setBounds(400, 280, 80, 40);
        add(setButton);


        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                student_service student_service_mapper=new student_serviceImpl();
                student student=new student();
                student.set_all( nameField.getText(), sexField.getText(), ageField.getText(), collegeField.getText(),
                        idField.getText(), passwordField.getText());
                student_service_mapper.add_student(student);
            }
        });

        setButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                student_service student_service_mapper=new student_serviceImpl();
                student student=new student();
                student.set_all( name, sex, age, college, id, password);
                student_service_mapper.update_student(student);
                System.out.println(student_service_mapper.update_student(student));
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
    }

    public static void main(String[] args) {
        student_info frame = new student_info("","","","","","");
        frame.setVisible(true);
    }


}
