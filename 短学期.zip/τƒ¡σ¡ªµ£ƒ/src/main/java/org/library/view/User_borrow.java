package org.library.view;

import org.library.pojo.book;
import org.library.service.book_service;
import org.library.service.impl.book_serviceImpl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class User_borrow extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;

    private String user_id;
    public User_borrow() {
        setTitle("图书管理系统");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);//固定大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);//绝对布局

        JLabel label = new JLabel("图书借阅");
        label.setFont(new Font("宋体", Font.BOLD, 30));
        label.setBounds(50, 30, 300, 80);
        add(label);

        JButton ascendButton = new JButton("剩余时间升序");
        ascendButton.setBounds(300, 30, 150, 50);
        add(ascendButton);

        JButton descendButton = new JButton("剩余时间降序");
        descendButton.setBounds(500, 30, 150, 50);
        add(descendButton);

        JButton backButton = new JButton("返回");
        backButton.setBounds(800, 30, 120, 60);
        add(backButton);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("书名");
        tableModel.addColumn("作者");
        tableModel.addColumn("分类");
        tableModel.addColumn("出版社");
        tableModel.addColumn("出版年份");
        tableModel.addColumn("借阅状态");
        tableModel.addColumn("借阅日期");
        tableModel.addColumn("剩余时间");
        table = new JTable(tableModel);

        // 添加数据
        book_service book_service_mapper=new book_serviceImpl();
        List<book> books=book_service_mapper.find_book_by_uid(user_id);
        for(book item:books){
            Object[] row={item.get_name(),item.get_author(),item.get_category(),
                    item.get_publisher(),item.get_year(),item.get_status(),item.get_brodate(),item.get_returndate()};
            tableModel.addRow(row);
        }
        // 创建滚动窗格
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 120, 800, 400);
        add(scrollPane);


        //剩余时间升序
        ascendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tableModel.setRowCount(0);
                book_service book_service_mapper=new book_serviceImpl();
                List<book> books=book_service_mapper.find_all_book_by_ASC();
                for(book item:books){
                    Object[] row={item.get_id(),item.get_name(),item.get_author(),item.get_category(),
                            item.get_place(),item.get_publisher(),item.get_year(),item.get_status(),item.get_brodate(),item.get_returndate()};
                    tableModel.addRow(row);
                }
            }
        });
        //剩余时间降序
        descendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tableModel.setRowCount(0);
                book_service book_service_mapper=new book_serviceImpl();
                List<book> books=book_service_mapper.find_all_book_by_DESC();
                for(book item:books){
                    Object[] row={item.get_id(),item.get_name(),item.get_author(),item.get_category(),
                            item.get_place(),item.get_publisher(),item.get_year(),item.get_status(),item.get_brodate(),item.get_returndate()};
                    tableModel.addRow(row);
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                teacher_manage frame = new teacher_manage();
                frame.setVisible(true);
            }
        });
    }

    public void setUser_id(String id){
        user_id=id;
    }
    public static void main(String[] args) {
        User_borrow frame = new User_borrow();
        frame.setVisible(true);
    }
}
