package org.library.dao;

import org.library.pojo.system_manager;
import org.library.pojo.library_manager;

import java.security.NoSuchAlgorithmException;
import java.util.List;

//DAO层负责访问数据库进⾏数据的操作，取得结果集，之后将结果集中的数据取出封装到VO类对象之后返回
//给service层（service后⾯会出现）
//创建Mapper代理接⼝（这是是dao接⼝）
public interface system_manager_Dao {
    //查询所有系统管理员信息
    List<system_manager> find_all_system_manager();
    //查询所有图书管理员信息
    List<library_manager> find_all_library_manger();


    // 按学号/工号查询管理员信息
    //返回一个system_manager对象
    system_manager find_system_manager_by_id(String id);


    // 根据输入的管理员信息进行动态条件检索
    //也就是传入一个system_manager，如果有相符合的system_manager就返回
    List<system_manager> find_system_manager(system_manager system_manager);


    //增加一个管理员
    int add_system_manager(system_manager system_manager);

    //更改管理员信息
    int update_system_manager(system_manager system_manager);

    //删除管理员
    int delete_system_manager_by_id(String aid);





}
