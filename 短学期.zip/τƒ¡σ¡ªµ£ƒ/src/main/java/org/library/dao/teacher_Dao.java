package org.library.dao;

import org.library.pojo.library_manager;
import org.library.pojo.teacher;

import java.util.List;

//DAO层负责访问数据库进⾏数据的操作，取得结果集，之后将结果集中的数据取出封装到VO类对象之后返回
//给service层（service后⾯会出现）
//创建Mapper代理接⼝（这是是dao接⼝）
public interface teacher_Dao {
    //查询所有系统管理员信息
    List<teacher> find_all_teacher();
    //查询所有图书管理员信息
    List<library_manager> find_all_library_manger();


    // 按学号/工号查询管理员信息
    //返回一个teacher对象
    teacher find_teacher_by_id(String id);


    // 根据输入的管理员信息进行动态条件检索
    //也就是传入一个teacher，如果有相符合的teacher就返回
    List<teacher> find_teacher(teacher teacher);


    //增加一个管理员
    int add_teacher(teacher teacher);

    //更改管理员信息
    int update_teacher(teacher teacher);

    //删除管理员
    int delete_teacher_by_id(String aid);





}
