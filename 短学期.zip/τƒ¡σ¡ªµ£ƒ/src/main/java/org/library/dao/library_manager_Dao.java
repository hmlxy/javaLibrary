package org.library.dao;

import org.library.pojo.library_manager;
import org.library.pojo.library_manager;

import java.util.List;

//DAO层负责访问数据库进⾏数据的操作，取得结果集，之后将结果集中的数据取出封装到VO类对象之后返回
//给service层（service后⾯会出现）
//创建Mapper代理接⼝（这是是dao接⼝）
public interface library_manager_Dao {

    //查询所有图书管理员信息
    List<library_manager> find_all_library_manager();


    // 按学号/工号查询管理员信息
    //返回一个library_manager对象
    library_manager find_library_manager_by_id(String id);


    // 根据输入的管理员信息进行动态条件检索
    //也就是传入一个library_manager，如果有相符合的library_manager就返回
    List<library_manager> find_library_manager(library_manager library_manager);


    //增加一个管理员
    int add_library_manager(library_manager library_manager);

    //更改管理员信息
    int update_library_manager(library_manager library_manager);

    //删除管理员
    int delete_library_manager_by_id(String aid);





}
