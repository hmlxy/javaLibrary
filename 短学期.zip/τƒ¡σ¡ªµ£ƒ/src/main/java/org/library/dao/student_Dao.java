package org.library.dao;

import org.library.pojo.library_manager;
import org.library.pojo.student;

import java.util.List;

//DAO层负责访问数据库进⾏数据的操作，取得结果集，之后将结果集中的数据取出封装到VO类对象之后返回
//给service层（service后⾯会出现）
//创建Mapper代理接⼝（这是是dao接⼝）
public interface student_Dao {
    //查询所有系统管理员信息
    List<student> find_all_student();


    // 按学号/工号查询管理员信息
    //返回一个student对象
    student find_student_by_id(String id);


    // 根据输入的管理员信息进行动态条件检索
    //也就是传入一个student，如果有相符合的student就返回
    List<student> find_student(student student);


    //增加一个管理员
    int add_student(student student);

    //更改管理员信息
    int update_student(student student);

    //删除管理员
    int delete_student_by_id(String aid);





}
