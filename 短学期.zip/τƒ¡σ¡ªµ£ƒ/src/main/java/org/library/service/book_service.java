package org.library.service;
import org.library.pojo.book;

import java.util.List;

//DAO层负责访问数据库进⾏数据的操作，取得结果集，之后将结果集中的数据取出封装到VO类对象之后返回
//给service层（service后⾯会出现）
//创建Mapper代理接⼝（这是是dao接⼝）
public interface book_service {
    //查询所有图书信息
    //List<Book>则是一个列表对象，用来存储多个图书对象
    List<book> find_all_book();

    List<book> find_all_book_by_ASC();
    List<book> find_all_book_by_DESC();
    // 按图书编号查询图书信息
    book find_book_by_id(String Bid);
    List<book> find_book_by_uid(String Bid);

    // 根据输入的图书信息进行动态条件检索
    //也就是传入一个Book的属性，如果有相符合的Book就返回
    //比如作者，书名
    List<book> find_book(book book);


    //增加一个图书
    int add_book(book book);

    //更改图书信息
    int update_book(book book);

    //删除图书
    int delete_book_by_id(String Bid);

    //根据书名统计数量
    int get_count_by_name(String Bname);

    //根据作者统计数量
    int get_count_by_author(String Bauthor);

    //根据分类统计数量
    int get_count_by_category(String Bcategory);

    //还书，根据图书id将图书的借阅信息为“可借”，然后消除日期
    int update_return_book(book book);






}
