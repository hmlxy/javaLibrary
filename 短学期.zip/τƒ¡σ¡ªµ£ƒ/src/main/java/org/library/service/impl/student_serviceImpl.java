package org.library.service.impl;

import org.apache.ibatis.session.SqlSession;
import org.library.dao.student_Dao;
import org.library.pojo.student;
import org.library.service.student_service;
import org.library.utils.MybatisUtils;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import static org.library.utils.ShaUtils.SHA256Encrypt;

//项⽬开发实践中，在进⾏业务处理时，⼀般不会直接调⽤DAO层的接⼝，⽽时将业务逻辑处理封装到service层
//service层：主要去负责⼀些业务逻辑处理。Service层的业务实现，具体要调⽤到已定义的DAO层的接⼝。封装
//Service层的业务逻辑有利于通⽤的业务逻辑的独⽴性和重复利⽤性。
public class student_serviceImpl implements student_service {
    //student_ServiceImpl 是一个 Java 类，实现了 student_Service 接口。接口提供了一些方法的定义，而 student_ServiceImpl 实现了这些方法的具体实现。
    private SqlSession sqlSession;
    private student_Dao mapper;

    public student_serviceImpl(){
        // 获取sqlSession
        sqlSession = MybatisUtils.getSqlSession();
        // 获取mapper接口
        mapper = sqlSession.getMapper(student_Dao.class);
    }


    @Override
    //返回所有的管理员信息
    public List<student> find_all_student() {
        return mapper.find_all_student();
    }

    //根据输入的id查询管理员对象
    @Override
    public student find_student_by_id(String aid) {
        return mapper.find_student_by_id(aid);
    }

    //根据对象的属性筛选符合条件的管理员信息
    @Override
    public List<student> find_student(student student) {
        return mapper.find_student(student);
    }

    //根据管理员对象添加一个管理员
    @Override
    public int add_student(student student) {
        return mapper.add_student(student);
    }

    //根据一个管理员对象更新管理员信息
    @Override
    public int update_student(student student_) {
        return mapper.update_student(student_);
    }

    //根据管理员id删除一个管理员
    @Override
    public int delete_student_by_id(String aid) {
        return mapper.delete_student_by_id(aid);
    }


    //根据输入的id和密码管理员登录判断是否存在
    @Override
    public boolean student_login(String id, String password) throws NoSuchAlgorithmException {
        student login_student = find_student_by_id(id);
        //如果不存在直接返回
        if(login_student == null){
            return false;
        }
        String student_password = login_student.get_password();
//        System.out.println("原密码"+student_password);
        String encryptpwd = SHA256Encrypt(password);
//        System.out.println("输入密码"+encryptpwd);

        // 用 equals() 比较两个字符串是否相等,则返回正确的权限
        if (encryptpwd.equals(student_password)) {
            return true;
        }
        return false;
    }


}
