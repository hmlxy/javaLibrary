package org.library.service;

import org.library.pojo.system_manager;

import java.security.NoSuchAlgorithmException;
import java.util.List;

public interface system_manager_service {
    //查询所有管理员信息
    List<system_manager> find_all_system_manager();

    // 按学号查询管理员信息
    system_manager find_system_manager_by_id(String aid);

    // 根据输入的管理员信息进行动态条件检索
    List<system_manager> find_system_manager(system_manager system_manager);

    //增加一个管理员信息
    int add_system_manager(system_manager system_manager);

    //更改管理员信息
    int update_system_manager(system_manager system_manager);

    //删除管理员信息
    int delete_system_manager_by_id(String aid);

    //判断管理员登录
    boolean system_manager_login(String id, String password) throws NoSuchAlgorithmException;

}
