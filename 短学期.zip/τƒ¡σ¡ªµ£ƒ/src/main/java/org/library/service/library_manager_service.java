package org.library.service;

import org.library.pojo.library_manager;

import java.security.NoSuchAlgorithmException;
import java.util.List;

public interface library_manager_service {
    //查询所有管理员信息
    List<library_manager> find_all_library_manager();

    // 按学号查询管理员信息
    library_manager find_library_manager_by_id(String aid);

    // 根据输入的管理员信息进行动态条件检索
    List<library_manager> find_library_manager(library_manager library_manager);

    //增加一个管理员信息
    int add_library_manager(library_manager library_manager);

    //更改管理员信息
    int update_library_manager(library_manager library_manager);

    //删除管理员信息
    int delete_library_manager_by_id(String aid);

    //判断管理员登录
    boolean library_manager_login(String id, String password) throws NoSuchAlgorithmException;

}
