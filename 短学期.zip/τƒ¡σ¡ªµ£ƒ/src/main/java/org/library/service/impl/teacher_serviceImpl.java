package org.library.service.impl;

import org.apache.ibatis.session.SqlSession;
import org.library.dao.teacher_Dao;
import org.library.pojo.teacher;
import org.library.service.teacher_service;
import org.library.utils.MybatisUtils;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import static org.library.utils.ShaUtils.SHA256Encrypt;

//项⽬开发实践中，在进⾏业务处理时，⼀般不会直接调⽤DAO层的接⼝，⽽时将业务逻辑处理封装到service层
//service层：主要去负责⼀些业务逻辑处理。Service层的业务实现，具体要调⽤到已定义的DAO层的接⼝。封装
//Service层的业务逻辑有利于通⽤的业务逻辑的独⽴性和重复利⽤性。
public class teacher_serviceImpl implements teacher_service {
    //teacher_ServiceImpl 是一个 Java 类，实现了 teacher_Service 接口。接口提供了一些方法的定义，而 teacher_ServiceImpl 实现了这些方法的具体实现。
    private SqlSession sqlSession;
    private teacher_Dao mapper;

    public teacher_serviceImpl(){
        // 获取sqlSession
        sqlSession = MybatisUtils.getSqlSession();
        // 获取mapper接口
        mapper = sqlSession.getMapper(teacher_Dao.class);
    }


    @Override
    //返回所有的管理员信息
    public List<teacher> find_all_teacher() {
        return mapper.find_all_teacher();
    }

    //根据输入的id查询管理员对象
    @Override
    public teacher find_teacher_by_id(String aid) {
        return mapper.find_teacher_by_id(aid);
    }

    //根据对象的属性筛选符合条件的管理员信息
    @Override
    public List<teacher> find_teacher(teacher teacher) {
        return mapper.find_teacher(teacher);
    }

    //根据管理员对象添加一个管理员
    @Override
    public int add_teacher(teacher teacher) {
        return mapper.add_teacher(teacher);
    }

    //根据一个管理员对象更新管理员信息
    @Override
    public int update_teacher(teacher teacher_) {
        return mapper.update_teacher(teacher_);
    }

    //根据管理员id删除一个管理员
    @Override
    public int delete_teacher_by_id(String aid) {
        return mapper.delete_teacher_by_id(aid);
    }


    //根据输入的id和密码管理员登录判断是否存在
    @Override
    public boolean teacher_login(String id, String password) throws NoSuchAlgorithmException {
        teacher login_teacher = find_teacher_by_id(id);
        //如果不存在直接返回
        if(login_teacher == null){
            return false;
        }
        String teacher_password = login_teacher.get_password();
//        System.out.println("原密码"+teacher_password);
        String encryptpwd = SHA256Encrypt(password);
//        System.out.println("输入密码"+encryptpwd);

        // 用 equals() 比较两个字符串是否相等,则返回正确的权限
        if (encryptpwd.equals(teacher_password)) {
            return true;
        }
        return false;
    }


}
