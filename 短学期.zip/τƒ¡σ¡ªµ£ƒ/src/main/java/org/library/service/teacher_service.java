package org.library.service;

import org.library.pojo.teacher;

import java.security.NoSuchAlgorithmException;
import java.util.List;

public interface teacher_service {
    //查询所有管理员信息
    List<teacher> find_all_teacher();

    // 按学号查询管理员信息
    teacher find_teacher_by_id(String aid);

    // 根据输入的管理员信息进行动态条件检索
    List<teacher> find_teacher(teacher teacher);

    //增加一个管理员信息
    int add_teacher(teacher teacher);

    //更改管理员信息
    int update_teacher(teacher teacher);

    //删除管理员信息
    int delete_teacher_by_id(String aid);

    //判断管理员登录
    boolean teacher_login(String id, String password) throws NoSuchAlgorithmException;

}
