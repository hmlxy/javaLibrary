package org.library.service;

import org.library.pojo.student;

import java.security.NoSuchAlgorithmException;
import java.util.List;

public interface student_service {
    //查询所有管理员信息
    List<student> find_all_student();

    // 按学号查询管理员信息
    student find_student_by_id(String aid);

    // 根据输入的管理员信息进行动态条件检索
    List<student> find_student(student student);

    //增加一个管理员信息
    int add_student(student student);

    //更改管理员信息
    int update_student(student student);

    //删除管理员信息
    int delete_student_by_id(String aid);

    //判断管理员登录
    boolean student_login(String id, String password) throws NoSuchAlgorithmException;

}
