/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 80012
Source Host           : localhost:3306
Source Database       : library

Target Server Type    : MYSQL
Target Server Version : 80012
File Encoding         : 65001

Date: 2023-06-28 14:08:30
*/

SET FOREIGN_KEY_CHECKS=0;

Create Database library;
use library;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
                        `id` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '图书编号',
                        `name` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '图书名称',
                        `author` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '图书作者',
                        `category` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '分类',
                        `place` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '图书位置',
                        `publisher` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '出版社',
                        `year` date DEFAULT NULL COMMENT '出版年份',
                        `status` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '借阅状态',
                        `uid` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '借阅者id',
                        `brodate` date DEFAULT NULL COMMENT '借阅时间',
                        `returndate` date DEFAULT NULL COMMENT '应还日期',
                        PRIMARY KEY (`id`),
                        UNIQUE KEY `Bid` (`id`),
                        KEY `Uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES ('2023WX0005', '雪国', '川端康成', '日本文学', '2楼西区20排B面4列1层', null, null, '已借出', '202305', '2023-06-26', '2023-07-26');
INSERT INTO `book` VALUES ('2023WX0012', '晚熟的人', '莫言', '中国文学', '2楼西区17排A面2列1层', null, null, '可借', null, null, null);
INSERT INTO `book` VALUES ('2023WX0017', '古都', '川端康成', '日本文学', '2楼西区20排B面4列2层', null, null, '已借出', '202305', '2023-04-20', '2023-06-19');
INSERT INTO `book` VALUES ('2023WX0018', '伊豆的舞女', '川端康成', '日本文学', '2楼西区20排B面4列1层', null, null, '已借出', '202305', '2023-04-21', '2023-06-20');
INSERT INTO `book` VALUES ('2023WX0023', '雪国', '川端康成', '日本文学', '2楼西区20排B面4列1层', null, null, '已借出', '2023212206', '2023-04-21', '2023-05-21');
INSERT INTO `book` VALUES ('2023WX0025', '蛙', '莫言', '中国文学', '2楼西区17排A面2列1层', null, null, '已借出', '2023212204', '2023-04-20', '2023-05-20');
INSERT INTO `book` VALUES ('2023WX0036', '蛙', '莫言', '中国文学', '2楼西区17排A面2列1层', null, null, '已借出', '202305', '2023-04-22', '2023-06-21');
INSERT INTO `book` VALUES ('2023WX0089', '古都', '川端康成', '日本文学', '2楼西区20排B面4列2层', null, null, '可借', null, null, null);
INSERT INTO `book` VALUES ('2023WX1019', '克苏鲁瑞秋魔法师', '塞拉芬娜', '剑圣文学', '3楼西区2排B面4列1层', '伊甸出版社', '2023-05-05', '已借出', '202305', '2023-05-05', '2023-06-04');
INSERT INTO `book` VALUES ('2023WX198', '狼王伊甸泰坦', '古老者', '文学', '3楼西区2排B面4列1层', '中国出版社', '2023-06-15', '已借出', '202305', '2023-06-15', '2023-07-15');
INSERT INTO `book` VALUES ('2023WX212', '黑龙麦丝玛拉巨人', '麦丝玛拉', '海怪文学', '3楼西区2排B面4列1层', '卡伊出版社', '2023-04-15', '已借出', '202305', '2023-04-15', '2023-05-15');
INSERT INTO `book` VALUES ('2023WX311', '夜魔艾薇儿魔法师', '麦丝玛拉', '黑龙文学', '3楼西区2排B面4列1层', '艾米莉亚出版社', '2023-03-14', '已借出', '202305', '2023-03-14', '2023-04-13');
INSERT INTO `book` VALUES ('2023WX440', '狮鹫伊甸猛犸', '蕾雅', '火龙文学', '3楼西区2排B面4列1层', '泰丝拉出版社', '2023-06-09', '已借出', '202305', '2023-06-09', '2023-07-09');
INSERT INTO `book` VALUES ('2023WX483', '矮人伊甸凤凰', '艾薇儿', '鸟人文学', '3楼西区2排B面4列1层', '斯蒂芬妮出版社', '2023-06-24', '已借出', '202305', '2023-06-24', '2023-07-24');
INSERT INTO `book` VALUES ('2023WX787', '凤凰卡伊狼王', '皮皮', '冰龙文学', '3楼西区2排B面4列1层', '乔伊出版社', '2023-01-21', '可借', null, null, null);

-- ----------------------------
-- Table structure for library_manager
-- ----------------------------
DROP TABLE IF EXISTS `library_manager`;
CREATE TABLE `library_manager` (
                                   `id` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                                   `name` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                                   `password` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                                   `phone` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                                   PRIMARY KEY (`id`),
                                   UNIQUE KEY `Aid` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of library_manager
-- ----------------------------
INSERT INTO `library_manager` VALUES ('2023106', '何明', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023204', '陈碧华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023313', '李明华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023333', '杨碧华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023380', '郭建国', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023412', '何平', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023427', '王明华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023434', '孙东', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023562', '罗文', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023566', '黄强', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023568', '孙鹤', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023583', '朱东', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023666', '杨红', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023706', '吴洋', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023811', '郑芳', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023878', '吴平', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023884', '罗建国', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023899', '张琴', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023909', '郭碧华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023984', '高少华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `library_manager` VALUES ('2023985', '何生', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
                           `id` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                           `name` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                           `sex` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                           `age` int(11) DEFAULT NULL,
                           `dept` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                           `password` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                           PRIMARY KEY (`id`),
                           UNIQUE KEY `Uid` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('202305', '欢乐', '女', '23', '物联网', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('202307', '非农', '男', '19', '师范', '123456jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('20231391', '周强', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('2023192', '何建国', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('2023212204', '马田', '男', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('2023212206', '周国', '男', '22', '软工', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('2023212208', '四流', '女', '20', '金融', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('20232304', '刘明华', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('20232440', '李东', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('20233062', '朱明', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('20233282', '郑强', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('2023424', '孙琴', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('20234442', '宋明', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('2023488', '李生', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('2023697', '高芬', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `student` VALUES ('2023754', '郭琴', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');

-- ----------------------------
-- Table structure for system_manger
-- ----------------------------
DROP TABLE IF EXISTS `system_manger`;
CREATE TABLE `system_manger` (
                                 `id` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                                 `name` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                                 `password` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                                 `phone` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                                 PRIMARY KEY (`id`),
                                 UNIQUE KEY `Aid` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of system_manger
-- ----------------------------
INSERT INTO `system_manger` VALUES ('2023106', '何明', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023204', '陈碧华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023313', '李明华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023333', '杨碧华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023380', '郭建国', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023412', '何平', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023427', '王明华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023434', '孙东', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023562', '罗文', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023566', '黄强', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023568', '孙鹤', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023583', '朱东', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023666', '杨红', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023706', '吴洋', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023811', '郑芳', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023878', '吴平', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023884', '罗建国', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023899', '张琴', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023909', '郭碧华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023984', '高少华', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');
INSERT INTO `system_manger` VALUES ('2023985', '何生', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=', '256922335');

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
                           `id` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                           `name` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                           `sex` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                           `age` int(11) DEFAULT NULL,
                           `dept` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                           `password` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                           PRIMARY KEY (`id`),
                           UNIQUE KEY `Uid` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('202305', '欢乐', '女', '23', '物联网', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('202307', '非农', '男', '19', '师范', '123456jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('20231391', '周强', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('2023192', '何建国', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('2023212204', '马田', '男', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('2023212206', '周国', '男', '22', '软工', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('2023212208', '四流', '女', '20', '金融', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('20232304', '刘明华', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('20232440', '李东', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('20233062', '朱明', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('20233282', '郑强', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('2023424', '孙琴', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('20234442', '宋明', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('2023488', '李生', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('2023697', '高芬', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
INSERT INTO `teacher` VALUES ('2023754', '郭琴', '女', '21', '计算机', 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=');
